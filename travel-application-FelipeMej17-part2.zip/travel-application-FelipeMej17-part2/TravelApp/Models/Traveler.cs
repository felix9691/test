using System.Collections.Generic;
using TravelApp.Data; 

namespace TravelApp.Models
{
    public class Traveler
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Style { get; set; }
        public List<Destination> Destinations { get; set; } = new();
    }
}